﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FzLib.Algorithm.DataStructure.Tree
{
    public abstract class BinaryTreeNodeBase<TData, TNode> where TNode : BinaryTreeNodeBase<TData, TNode>
    {
        public BinaryTreeNodeBase()
        {

        }
        public BinaryTreeNodeBase(TData data)
        {
            Data = data;
        }

        public BinaryTreeNodeBase(TData data, TNode left, TNode right) : this(data)
        {
            LeftChild = left;
            RightChild = right;
        }
        public TData Data { get; set; }

        public virtual TNode LeftChild { get; set; }
        public virtual TNode RightChild { get; set; }
        public virtual TNode Parent { get; set; }

    }
}
