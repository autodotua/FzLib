﻿namespace FzLib.Geography
{
    public static class Constant
    {
        public const double EarthRadius = 6378137;

        public const string GpxTimeFormat = "yyyy-MM-ddTHH:mm:ssZ";
    }
}
